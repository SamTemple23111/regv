<?php

require("header-l.html");
?>


<?
require("load.html");
?>


<?
require("footer.html");
?>