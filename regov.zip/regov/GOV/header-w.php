<!DOCTYPE html>
<html lang="en"><head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>
    Sign in
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/png" sizes="32x32" href="log_files/favicon-32x32.png">
  	<link rel="icon" type="image/png" sizes="16x16" href="log_files/favicon-16x16.png">
  	<link href="loadGOV_files/css.css" rel="stylesheet">
  <link rel="stylesheet" href="loadGOV_files/main.css">
  <link rel="javascript" href="cold_files/jquery.js">
  <link rel="javascript" href="cold_files/main.js">

  <style>
    
#html-spinner, #svg-spinner{
  -webkit-transition-property: -webkit-transform;
  -webkit-transition-duration: 1.2s;
  -webkit-animation-name: rotate;
  -webkit-animation-iteration-count: infinite;
  -webkit-animation-timing-function: linear;
  
  -moz-transition-property: -moz-transform;
  -moz-animation-name: rotate; 
  -moz-animation-duration: 1.2s; 
  -moz-animation-iteration-count: infinite;
  -moz-animation-timing-function: linear;
  
  transition-property: transform;
  animation-name: rotate; 
  animation-duration: 1.2s; 
  animation-iteration-count: infinite;
  animation-timing-function: linear;
}

@-webkit-keyframes rotate {
    from {-webkit-transform: rotate(0deg);}
    to {-webkit-transform: rotate(360deg);}
}

@-moz-keyframes rotate {
    from {-moz-transform: rotate(0deg);}
    to {-moz-transform: rotate(360deg);}
}

@keyframes rotate {
    from {transform: rotate(0deg);}
    to {transform: rotate(360deg);}
}

</style>


</head>

<body>
  <header role="banner" class="header">
    <section class="wrapper">
      <div class="inner">
        <div class="cbLogin-grid">
          <div class="cbLogin-grid-row">
            <a href="https://beta.my.gov.au/" class="cbLogin-logo__link">
              <img id="cbLogin-logo" src="loadGOV_files/logo-dark.svg" role="img">
            </a>

            <div class="header-links">
              <a href="https://beta.my.gov.au/en/about/help">Help</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  </header>