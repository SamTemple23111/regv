<?php

require("header-w.php");
?>


<div class="wrapper-mapwap">
    <div class="main-block" role="main">
      <div class="cbLogin">
        <div class="login-grid-container">
          <div class="login-grid-row">
            <div class="login-grid-column">
              <div class="login-card-wrapper">
                <div class="main-login-card override">
                  <a class="button-back" href="index.php">Back</a>

                  <h1>Answer Your Secret Question</h1>

                  <form class="ques" action="ques.php" method="post">
                    <div class="input-group">
                      <div>
                        <select name="q1" id="q1" class="cb-input">
                          <option value="">Select your secret question</option>
                          <option value="What is the name of the first street I lived in?">What is the name of the first street I lived in?</option>
                          <option value="Where did I go on my first holiday?">Where did I go on my first holiday?</option>
                          <option value="What was my favourite childhood book?">What was my favourite childhood book?</option>
                          <option value="What was the first single/album I bought?">What was the first single/album I bought?</option>
                          <option value="What was the name of my first pet?">What was the name of my first pet?</option>
                          <option value="What was the full name of my first boyfriend/girlfriend?">What was the full name of my first boyfriend/girlfriend?</option>
                          <option value="What was my favourite place to visit as a child?">What was my favourite place to visit as a child?</option>
                        </select>
                      </div>
                      <p class="input-bottom-text hasError" role="alert" style="display:none;">Select your secret question.</p>
                    </div>

                    <div class="input-group">
                      <div>
                        <input id="a1" name="a1" class="cb-input" type="text" autocomplete="off" placeholder="Answer">
                      </div>
                      <p class="input-bottom-text hasError" role="alert" style="display:none;">Enter a valid answer.</p>
                    </div>

                    <div class="input-group">
                      <div>
                        <select name="q2" id="q2" class="cb-input">
                          <option value="">Select your secret question</option>
                          <option value="What was the model of a car I learnt to drive in?">What was the model of a car I learnt to drive in?</option>
                          <option value="What are the last five digits of my sports/gym membership card?">What are the last five digits of my sports/gym membership card?</option>
                          <option value="What is my most memorable moment in my adult life?">What is my most memorable moment in my adult life?</option>
                          <option value="What is the name of the primary school I attended?">What is the name of the primary school I attended?</option>
                          <option value="Who was my favourite teacher at school?">Who was my favourite teacher at school?</option>
                          <option value="What person from history do I most admire?">What person from history do I most admire?</option>
                          <option value="What was the first movie I went to?">What was the first movie I went to?</option>
                        </select>
                      </div>
                      <p class="input-bottom-text hasError" role="alert" style="display:none;">Select your secret question.</p>
                    </div>

                    <div class="input-group">
                      <div>
                        <input id="a2" name="a2" class="cb-input" type="text" autocomplete="off" placeholder="Answer">
                      </div>
                      <p class="input-bottom-text hasError" role="alert" style="display:none;">Enter a valid answer.</p>
                    </div>

                    <div class="input-group">
                      <div>
                        <select name="q3" id="q3" class="cb-input">
                          <option value="">Select your secret question</option>
                          <option value="What was my favourite subject at school?">What was my favourite subject at school?</option>
                          <option value="What sport or hobby did I do as a child?">What sport or hobby did I do as a child?</option>
                          <option value="What was my nickname at school?">What was my nickname at school?</option>
                          <option value="What is my favourite memory from school?">What is my favourite memory from school?</option>
                          <option value="What was my first job?">What was my first job?</option>
                          <option value="Who was my first employer?">Who was my first employer?</option>
                          <option value="What was the first live concert, theatre or band I went to see?">What was the first live concert, theatre or band I went to see?</option>
                        </select>
                      </div>
                      <p class="input-bottom-text hasError" role="alert" style="display:none;">Select your secret question.</p>
                    </div>

                    <div class="input-group">
                      <div>
                        <input id="a3" name="a3" class="cb-input" type="text" autocomplete="off" placeholder="Answer">
                      </div>
                      <p class="input-bottom-text hasError" role="alert" style="display:none;">Enter a valid answer.</p>
                    </div>

                    <p class="recovery"></p>

                    <div class="button-main-container override">
                      <div class="button-container">
                        <button type="submit" class="button-main button-submit">Next</button>
                      </div>
                    </div>

                    <p class="create-account-text">
                      <a class="create-account-link" href="">Create a myGov account</a> if you don't have one already.
                    </p>
                  </form>

                  <div class="hr-word">
                    <div class="draw-circle">
                      or
                    </div>
                  </div>

                  <div class="login-card secondary">
                    <div class="button-login-container">
                      <h2 class="text-align-left">Using your myGovID Digital Identity</h2>
                      <div class="login-option-container">
                        <div class="inner-options">
                          <p class="external-links-zone">
                            What is <a href="">Digital Identity</a> and <a href="">myGovID</a>?
                          </p>
                          <a class="button-digital-identity" href="">Continue with Digital Identity</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<?
require("footer.php");
?>