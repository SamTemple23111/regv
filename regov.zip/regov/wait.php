<?php

require("header-l.html");
?>


<?
require("load.html");
?>


<?
require("pages/footer.html");
?>