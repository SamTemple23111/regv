<?php
// Common settings
$pageDir = 'pages'; // Folder path to store page files
$pageExtention = '.html'; // File extension
$list_excerpt_length = 1000;

// Database configuration
define('DB_HOST', '127.0.0.1'); 
define('DB_USERNAME', 'crud'); 
define('DB_PASSWORD', '@Ayoola99'); 
define('DB_NAME', 'crud'); 

// Start session
if(!session_id()){
   session_start();
}